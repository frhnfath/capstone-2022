package com.frhnfath.githubuserapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.frhnfath.githubuserapp.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "Detail Page"

        val data = intent.getParcelableExtra<User>("DATA")
        Log.d("Data Detail", data?.following.toString())
        Log.d("Data Detail 2", data?.username.toString())

        if (data != null) {
            binding.imgDetail.setImageResource(data.photo)
            binding.tvDetailUsername.text = data.username
            binding.tvDetailName.text = data.name
            binding.repositoryNumber.text = data.repository.toString()
            binding.followingNumber.text = data.following.toString()
            binding.followersNumber.text = data.followers.toString()
            binding.locationInfo.text = data.location
            binding.companyInfo.text = data.company
        }
    }
}